package com.example.students;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class GroupActivity extends AppCompatActivity {
    private Group mGroup;
    private ArrayList<Student> mRemovedStudents;
    private ListView mListViewStudents;
    private ActivityResultLauncher<Intent> mActivityResultLauncherGroup;

    private ArrayList<GroupNameID> mGroupNamIDS

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);

        Bundle bundle = getIntent().getExtras();

        mGroup = ((Group) bundle.getParcelable("group"));
        mRemovedStudents = bundle.getParcelableArrayList("removedStudents");
        mRemovedStudents = bundle.getParcelablExtrs("nameid")
        mListViewStudents = findViewById(R.id.lvStudents);
        setTitle(mGroup.getName());

        mListViewStudents.setAdapter(
                new StudentListAdapter(
                        this,
                        mGroup,
                        (parent, view, position, id) -> deleteStudentDialog(position),
                        (parent, view, position, id) -> editInvoke(position)
                ));

        mActivityResultLauncherGroup = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            Intent intent = result.getData();
                            long position = intent.getLongExtra("position", 0);
                            Student student = ((Student) intent.getParcelableExtra("student"));
                            if (position != -1) {
                                mGroup.setStudentByID(student.getId(), student);
                            }
                            else mGroup.addStudentToGroup(student);
                            ((StudentListAdapter) mListViewStudents.getAdapter()).notifyDataSetChanged();
                        }
                    }
                });
    }

    private boolean deleteStudentDialog(int position) {
        AlertDialog.Builder infoDialog = new AlertDialog.Builder(GroupActivity.this);
        infoDialog.setTitle("Подтверждение");
        infoDialog.setMessage("Удалить студента ?");
        infoDialog.setCancelable(false);
        infoDialog.setNegativeButton("Нет", null);
        infoDialog.setPositiveButton("Да", (dialog, which) -> {
            mRemovedStudents.add(mGroup.getStudent((long) position + 1));
            Log.d("MyLog", "" + mRemovedStudents);
            mGroup.deleteStudent(position);
            ((StudentListAdapter) mListViewStudents.getAdapter()).notifyDataSetChanged();
        });
        infoDialog.show();

        return true;
    }

    private void editInvoke(int position) {
        Student selectedStudent = mGroup.getStudents().get(position);
        Intent intent = new Intent(this, StudentActivity.class);
        intent.putExtra("student", selectedStudent);
        intent.putExtra("position", position);
        mActivityResultLauncherGroup.launch(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.group_menu, menu);
        if (mGroup.getID() == -1) {
            menu.findItem(R.id.miSetGroup).setVisible(true);
            return true;
        }
        menu.findItem(R.id.miSetGroup).setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.miAddStudent) {
            Intent intent = new Intent(this, StudentActivity.class);
            intent.putExtra("position", -1L);
            mActivityResultLauncherGroup.launch(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("group", mGroup);
        intent.putExtra("removedStudents", mRemovedStudents);
        setResult(RESULT_OK, intent);
        super.onBackPressed();
    }
}
