package com.example.students;

public class StudentForGroup implements Parcelable {
    private Student mStudent;
    private Long mGroupID;

    public StudentForGroup(Student student, Long groupID){
        mStudent = student;
        mGroupID = groupID;
    }

    protected StudentForGroup(Parcel in){
        mStudent = in.readParcelable(Student.class.getClassLoader());
        if (in.readByte() == 0) {
            mGroupID == null;
        }
        else {
            mGroupID = in.readLong();
        }
    }

    public void writeToParcel(Parcel dest, int flags){
        dest.writeParcelable(mStudent, flags);
        if (mGroupID == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1)
        }
    }

    public int describeContents() {
        return 0;
    }

    public static final Creator<StudentForGroup> CREATOR = new Creator <StudentForGroup>() {

        public StudentForGroup createFromParcel(Parcel in) { return new StudentForGroup(in);}

        /////
    };

    puplic Student

    public Student getStudent() {
        return mStudent;
    }

    public Student getGroupID() {
        return mGroupID;
    }
}

