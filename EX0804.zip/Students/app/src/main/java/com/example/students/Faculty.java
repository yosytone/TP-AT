package com.example.students;

import java.util.ArrayList;

public class Faculty {
    private String mName;
    private ArrayList<Group> mGroups;

    public Faculty(String name) {
        mName = name;
        mGroups = new ArrayList<>();
    }

    public ArrayList<GroupNameID> getGroupNameIDList(){
        ArrayList<GroupNameID> groupNameIDS = new ArrayList<>();
        for (Group g : mGroups) {
            groupNameIDS.add(new GroupNameID(g.getName(), g.getID()));
        }
        return groupNameIDS;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public ArrayList<Group> getGroups() {
        return mGroups;
    }

    public void setGroups(ArrayList<Group> groups) {
        mGroups = groups;
    }

    public void addGroup(Group group) {
        mGroups.add(group);
    }

    public Group findStudentGroup(Student student) {
        for (Group g: mGroups) {
            if (g.hasStudent(student)) return g;
        }

        return null;
    }

    public Group findGroup(Long id) {
        for (Group g: mGroups) {
            if (g.getID() == id) return g;
        }

        return null;
    }

    public void deleteGroups() {
        mGroups.clear();
    }

    public void deleteGroup(int position) {
        mGroups.remove(position);
    }
}
