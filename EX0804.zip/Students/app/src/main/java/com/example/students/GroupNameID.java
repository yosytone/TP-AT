package com.example.students;

public class GroupNameID implements Parcelable {
    private String mName;
    private Long mID;

    public GroupNameID(String name, Long ID) {
        mName = name;
        mID = ID;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public Long getID() {
        return mID;
    }

    public void setID(Long ID) {
        mID = ID;
    }

    protected GroupNameID(Parcel in) {
        mName = in.readString();
        if (in.readByte()==0){
            mID = null;
        }
        else {
            mID = in.readLong();
        }
    }

    public void writeToParcel(Parcel dest, int flags){
        //
    }



}
