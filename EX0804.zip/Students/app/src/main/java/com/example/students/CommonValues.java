package com.example.students;

public class CommonValues {
    private static Long mLastStudentId;
    private static Long mLastGroupId;

    public static Long getStudentId() {
        if (mLastStudentId == null) mLastStudentId = 0L;
        return ++mLastStudentId;
    }

    public static Long getGroupId() {
        if (mLastGroupId == null) mLastGroupId = 0L;
        return ++mLastGroupId;
    }
}
