package com.example.students;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.Calendar;

public class Student implements Parcelable {
    private String mSurname, mFirstname, mMiddlename;
    private Long mId;
    private Calendar mBirthdate;

    private Student(String surname, String firstname, String middlename, Calendar birthday) {
        mSurname = surname;
        mFirstname = firstname;
        mMiddlename = middlename;
        mBirthdate = birthday;
        mId = CommonValues.getStudentId();
    }

    protected Student(Parcel in) {
        mSurname = in.readString();
        mFirstname = in.readString();
        mMiddlename = in.readString();
        if (in.readByte() == 0) {
            mId = null;
        } else {
            mId = in.readLong();
        }
        if (in.readByte() == 0) {
            mBirthdate = null;
        } else {
            mBirthdate = Calendar.getInstance();
            mBirthdate.setTimeInMillis(in.readLong());
        }
    }

    public static final Creator<Student> CREATOR = new Creator<Student>() {
        @Override
        public Student createFromParcel(Parcel in) {
            return new Student(in);
        }

        @Override
        public Student[] newArray(int size) {
            return new Student[size];
        }
    };

    public static Student CREATE(String surname, String firstname,
                                 String middlename, Calendar birthday) {
        return new Student(surname, firstname, middlename, birthday);
    }

    public String getSurname() {
        return mSurname;
    }

    public void setSurname(String surname) {
        mSurname = surname;
    }

    public String getFirstname() {
        return mFirstname;
    }

    public void setFirstname(String firstname) {
        mFirstname = firstname;
    }

    public String getMiddlename() {
        return mMiddlename;
    }

    public void setMiddlename(String middlename) {
        mMiddlename = middlename;
    }

    public Calendar getBirthday() {
        return mBirthdate;
    }

    public void setBirthday(Calendar birthday) {
        mBirthdate = birthday;
    }

    public Long getId() {
        return mId;
    }

    public Group getGroup(Faculty faculty) throws GroupNotFound {
        Group group = faculty.findStudentGroup(this);
        if (group == null) throw new GroupNotFound();

        return group;
    }

    @NonNull
    @Override
    public String toString() {
        return  mSurname + " " + mFirstname + " " + mMiddlename;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mSurname);
        dest.writeString(mFirstname);
        dest.writeString(mMiddlename);
        if (mId == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeLong(mId);
        }
        if (mBirthdate == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeLong(mBirthdate.getTimeInMillis());
        }
    }
}

