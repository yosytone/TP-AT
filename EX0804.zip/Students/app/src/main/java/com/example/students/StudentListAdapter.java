package com.example.students;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class StudentListAdapter extends BaseAdapter {
    private Group mGroup;
    private Context mContext;
    private LayoutInflater mInflater;
    private SimpleDateFormat mSimpleDateFormat;

    @Nullable
    private AdapterView.OnItemLongClickListener mDeleteCallback;
    @Nullable
    private AdapterView.OnItemClickListener mEditCallback;

    public StudentListAdapter(Context context, Group group,
                              @Nullable AdapterView.OnItemLongClickListener delete,
                              @Nullable AdapterView.OnItemClickListener edit) {
        mGroup = group;
        mContext = context;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mSimpleDateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.US);
        mDeleteCallback = delete;
        mEditCallback = edit;
    }

    @Override
    public int getCount() {
        return mGroup.getStudents().size();
    }

    @Override
    public Object getItem(int position) {
        return mGroup.getStudents().get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (mGroup.getStudents().isEmpty()) return convertView;
        View view = mInflater.inflate(R.layout.element_view_student, parent, false);

        Student student = mGroup.getStudents().get(position);
        String s = student.getSurname();
        if (!TextUtils.isEmpty(student.getFirstname())) {
            s = s + " " + student.getFirstname().charAt(0) + ".";
        }
        if (!TextUtils.isEmpty(student.getMiddlename())) {
            s = s + " " + student.getMiddlename().charAt(0) + ".";
        }

        ((TextView) view.findViewById(R.id.tvSEName)).setText(s);
        ((TextView) view.findViewById(R.id.tvSEBirthdate)).setText(
                mSimpleDateFormat.format(mGroup.getStudents().get(position).getBirthday().getTime())
        );

        ((Button) view.findViewById(R.id.btnSEEdit)).setOnClickListener(v -> {
            if (mEditCallback != null)
                mEditCallback.onItemClick((AdapterView<?>) parent, convertView, position, 0);
        });

        view.setOnLongClickListener(v -> {
            if (mDeleteCallback != null)
                mDeleteCallback.onItemLongClick((AdapterView<?>) parent, convertView, position, 0);
            return true;
        });

        return view;
    }
}
