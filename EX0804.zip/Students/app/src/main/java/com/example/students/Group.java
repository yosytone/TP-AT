package com.example.students;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class Group implements Parcelable {
    private String mName;
    private Long mID;
    private ArrayList<Student> mStudents;

    public Group(String name) {
        mName = name;
        mID = CommonValues.getGroupId();
        mStudents = new ArrayList<>();
    }

    protected Group(Parcel in) {
        mName = in.readString();
        if (in.readByte() == 0) {
            mID = null;
        } else {
            mID = in.readLong();
        }
        mStudents = in.createTypedArrayList(Student.CREATOR);
    }

    public static final Creator<Group> CREATOR = new Creator<Group>() {
        @Override
        public Group createFromParcel(Parcel in) {
            return new Group(in);
        }

        @Override
        public Group[] newArray(int size) {
            return new Group[size];
        }
    };

    public Long getID() {
        return mID;
    }

    public void setID(Long mID) {
        this.mID = mID;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public ArrayList<Student> getStudents() {
        return mStudents;
    }

    public void setStudents(ArrayList<Student> students) {
        mStudents = students;
    }

    public void addStudentToGroup(Student student) {
        mStudents.add(student);
    }

    public Student getStudent(Long Id) {
        for (Student s: mStudents) {
            Log.d("MyLog", "id = " + Id);
            Log.d("MyLog", "s.getId = " + s.getId());
            if (s.getId().equals(Id)) {
                return s;
            }
        }

        return null;
    }

    public boolean hasStudent(Student student) {
        for (Student s: mStudents) {
            if (s.getId() == student.getId()) return true;
        }

        return false;
    }

    public void deleteStudent(int position) {
        mStudents.remove(position);
    }

    public void setStudentByID(Long id, Student student){
        int i = 0;
        for (Student s:mStudents) {
            if (s.getId() == id) {
                mStudents.set(i, student);
            }
            i++;
        }
    }

    @NonNull
    @Override
    public String toString() {
        return mName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mName);
        if (mID == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeLong(mID);
        }
        dest.writeTypedList(mStudents);
    }
}
