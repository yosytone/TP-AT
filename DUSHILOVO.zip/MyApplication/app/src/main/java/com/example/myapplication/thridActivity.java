package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.Content.Intent;

public class thridActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thrid);

        setTitle((Intent) getIntent().getStringExtra("in param"));

        ((Button) findViewById(R.id.Third_button_1)).setOnClickListener( v ->{
            Intent intent = new Intent();
            intent.putExtra("param", ((EditText)) findViewById(R.id.et_input)).getText().toString() );
            setResult
                }
        );
    }
}