package com.example.students;

public class GroupNotFound extends Exception {
    public GroupNotFound() {
        super("Группа не найдена");
    }
}
