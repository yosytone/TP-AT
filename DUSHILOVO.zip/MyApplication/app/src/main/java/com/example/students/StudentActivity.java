package com.example.students;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.CalendarView;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class StudentActivity extends AppCompatActivity {
    private Student student;
    private Long position;
    private CalendarView mCalendarView;
    private Calendar c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        setTitle("Введите данные о студенте");

        Bundle bundle = getIntent().getExtras();
        position = bundle.getLong("position");

        mCalendarView = ((CalendarView) findViewById(R.id.cvCalendar));

        mCalendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            c = Calendar.getInstance();
            c.set(year, month, dayOfMonth);
            mCalendarView.setDate(c.getTimeInMillis());
        });

        if (position > -1) {
            student = bundle.getParcelable("student");
            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy", Locale.US);
            ((EditText) findViewById(R.id.eSurname)).setText(student.getSurname());
            ((EditText) findViewById(R.id.eFirstname)).setText(student.getFirstname());
            ((EditText) findViewById(R.id.eMiddlename)).setText(student.getMiddlename());
            mCalendarView.setDate(student.getBirthday().getTimeInMillis());
            c = student.getBirthday();
        }
    }

    @Override
    public void onBackPressed() {
        EditText mSurname = ((EditText) findViewById(R.id.eSurname));
        EditText mFirstname = ((EditText) findViewById(R.id.eFirstname));
        EditText mMiddlename = ((EditText) findViewById(R.id.eMiddlename));

        AlertDialog.Builder infoDialog = new AlertDialog.Builder(StudentActivity.this);
        infoDialog.setTitle("Подтверждение");
        infoDialog.setMessage("Подтвердить ?");
        infoDialog.setCancelable(false);

        infoDialog.setNegativeButton("Нет", (dialog, which) -> {
            super.onBackPressed();
        });

        infoDialog.setPositiveButton("Да", (dialog, which) -> {
            if (TextUtils.isEmpty(mSurname.getText().toString())) {
                mSurname.setError("Укажите фамилию");
            }
            if (TextUtils.isEmpty(mFirstname.getText().toString())) {
                mFirstname.setError("Укажите имя");
            }
            if (TextUtils.isEmpty(mMiddlename.getText().toString())) {
                mMiddlename.setError("Укажите отчество");
            }

            Intent intent = new Intent(this, GroupActivity.class);

            if (position == -1) {
                student = Student.CREATE(
                    mSurname.getText().toString(),
                    mFirstname.getText().toString(),
                    mMiddlename.getText().toString(),
                    c
                );
            } else {
                student.setSurname(mSurname.getText().toString());
                student.setFirstname(mFirstname.getText().toString());
                student.setMiddlename(mMiddlename.getText().toString());
                student.setBirthday(c);
            }

            intent.putExtra("student", student);
            intent.putExtra("position", position);

            setResult(RESULT_OK, intent);
            finish();
        });
        infoDialog.show();
    }
}