package com.example.students;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Faculty mFaculty;
    private Group mStudentsWithoutGroup;
    private Menu mMenu;
    private ListView mListViewGroups;
    private ActivityResultLauncher<Intent> mActivityResultLauncherGroup;
    private StudentForGroup

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mListViewGroups = findViewById(R.id.lvGroups);

        mActivityResultLauncherGroup = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            Intent intent = result.getData();
                            Group group = intent.getParcelableExtra("group");
                            ArrayList<Student> studentForGroups =
                                    intent.getParcelableArrayListExtra("removedStudents");
                            if (studentForGroups != null) {
                                for (StudentForGroup studentForGroup :studentForGroups)
                                    mFaculty.getGroups().get(studentForGroup.getGroupID().intValue()),
                                            addStudent(studentForGroup.getStudent());
                            }
                            Group g;
                            if (group.getID() != -1) g = mFaculty.findGroup(group.getID());
                            else g = mFaculty.getUnselectedGroup();
                            if (g != null) g.setStudents(group.getStudents());
                        }
                    }
                });

        SharedPreferences sPref = getPreferences(MODE_PRIVATE);
        String s = sPref.getString("faculty", "");
        if (TextUtils.isEmpty(s)) mFaculty = null;
        else {
            mFaculty = (new Gson()).fromJson(s, Faculty.class);
        }

        mStudentsWithoutGroup = new Group("Students without group");
        mStudentsWithoutGroup.setID(-1L);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.faculty_menu, menu);
        ((MenuItem) menu.findItem(R.id.miDeleteFaculty)).setVisible(false);
        mMenu = menu;
        updateFaculty();
        return true;
    }

    public void showExitDialog() {
        AlertDialog.Builder infoDialog = new AlertDialog.Builder(MainActivity.this);
        infoDialog.setTitle("Выход");
        infoDialog.setMessage("Вы точно хотите выйти?");
        infoDialog.setCancelable(false);
        infoDialog.setNegativeButton("Нет", null);
        infoDialog.setPositiveButton("Да", (dialog, which) -> finish());
        infoDialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.miNewFaculty: {
                AlertDialog inputDialog = new AlertDialog.Builder(MainActivity.this).create();
                inputDialog.setTitle("Введите название");
                inputDialog.setCancelable(false);
                View vv = (LinearLayout) getLayoutInflater().inflate(R.layout.faculty_input_layout,null);
                inputDialog.setView(vv);
                ((Button) vv.findViewById(R.id.btnNo)).setOnClickListener(v -> inputDialog.cancel());
                ((Button) vv.findViewById(R.id.btnYes)).setOnClickListener(v -> {
                    mFaculty = new Faculty(((EditText) vv.findViewById(R.id.eFacultyInput)).getText().toString());
                    updateFaculty();
                    inputDialog.cancel();
                });
                inputDialog.show();
                return true;
            }
            case R.id.miAbout: {
                AlertDialog.Builder infoDialog = new AlertDialog.Builder(MainActivity.this);
                infoDialog.setTitle("О программе");
                infoDialog.setMessage("Это программа группы 35/2");
                infoDialog.setCancelable(false);
                infoDialog.setPositiveButton("Прочитано", null);
                infoDialog.show();
                return true;
            }
            case R.id.miExit: {
                showExitDialog();
                return true;
            }
            case R.id.miDeleteFaculty: {
                AlertDialog.Builder infoDialog = new AlertDialog.Builder(MainActivity.this);
                infoDialog.setTitle("Подтверждение");
                infoDialog.setMessage("Удалить факультет?");
                infoDialog.setCancelable(true);
                infoDialog.setNegativeButton("Нет", null);
                infoDialog.setPositiveButton("Да", (dialog, which) -> {
                    mFaculty.deleteGroups();
                    mFaculty = null;
                    updateFaculty();
                });
                infoDialog.show();

                return true;
            }
            case R.id.miAddGroup: {
                AlertDialog inputDialog = new AlertDialog.Builder(MainActivity.this).create();
                inputDialog.setTitle("Введите номер группы");
                inputDialog.setCancelable(false);
                View vv = (LinearLayout) getLayoutInflater().inflate(R.layout.faculty_input_layout,null);
                inputDialog.setView(vv);
                ((EditText) vv.findViewById(R.id.eFacultyInput)).setHint("Название группы");
                ((Button) vv.findViewById(R.id.btnNo)).setOnClickListener(v -> {
                    inputDialog.cancel();
                });
                ((Button) vv.findViewById(R.id.btnYes)).setOnClickListener(v -> {
                    mFaculty.addGroup(new Group(((EditText) vv.findViewById(R.id.eFacultyInput)).getText().toString()));
                    ((ArrayAdapter) mListViewGroups.getAdapter()).notifyDataSetChanged();
                    inputDialog.cancel();
                });
                inputDialog.show();
                return true;
            }
            case R.id.miStudentsWithoutGroup: {
                Intent intent = new Intent(this, GroupActivity.class);
                intent.putExtra("group", mStudentsWithoutGroup);
                mActivityResultLauncherGroup.launch(intent);
            }

            default: {}
        }

        return super.onOptionsItemSelected(item);
    }

    public void updateFaculty() {
        if (mFaculty != null) {
            setTitle(mFaculty.getName());
            mMenu.findItem(R.id.miNewFaculty).setVisible(false);
            mMenu.findItem(R.id.miDeleteFaculty).setVisible(true);
            mMenu.findItem(R.id.miAddGroup).setVisible(true);
            mMenu.findItem(R.id.miStudentsWithoutGroup).setVisible(true);

            mListViewGroups.setAdapter(
                    new ArrayAdapter<Group>(
                            this,
                            android.R.layout.simple_list_item_1,
                            mFaculty.getGroups()
                    )
            );

            mListViewGroups.setOnItemLongClickListener(((parent, view, position, id) -> {
                AlertDialog.Builder infoDialog = new AlertDialog.Builder(MainActivity.this);
                infoDialog.setTitle("Подтверждение");
                infoDialog.setMessage("Удалить группу " + mFaculty.getGroups().get(position) + "?");
                infoDialog.setCancelable(true);
                infoDialog.setNegativeButton("Отмена", null);
                infoDialog.setPositiveButton("Удалить", (dialog, which) -> {
                    mFaculty.deleteGroup(position);
                    ((ArrayAdapter) mListViewGroups.getAdapter()).notifyDataSetChanged();
                });
                infoDialog.show();

                return true;
            }));

            mListViewGroups.setOnItemClickListener((parent, view, position, id) -> {
                ArrayList<Student> removedStudents = new ArrayList<>();
                Intent intent = new Intent(MainActivity.this, GroupActivity.class);
                intent.putExtra("group", mFaculty.getGroups().get(position));
                intent.putExtra("removedStudents", removedStudents);
                intent.putExtra("group_nameid", mFaculty.getGroupNameIDList());
                mActivityResultLauncherGroup.launch(intent);
            });

        } else {
            setTitle("");
            mMenu.findItem(R.id.miDeleteFaculty).setVisible(false);
            mMenu.findItem(R.id.miNewFaculty).setVisible(true);
            mMenu.findItem(R.id.miAddGroup).setVisible(false);
            mMenu.findItem(R.id.miStudentsWithoutGroup).setVisible(false);
            mListViewGroups.setAdapter(null);
            mListViewGroups.setOnItemLongClickListener(null);
            mListViewGroups.setOnItemClickListener(null);
        }
    }

    @Override
    protected void onDestroy() {
        if (mFaculty != null) {
            SharedPreferences.Editor ed = getPreferences(MODE_PRIVATE).edit();
            GsonBuilder builder = new GsonBuilder();
            Gson gson = builder.create();
            ed.putString("faculty", gson.toJson(mFaculty));
            ed.apply();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        showExitDialog();
    }
}