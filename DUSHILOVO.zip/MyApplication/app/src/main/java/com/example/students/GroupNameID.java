package com.example.students;

import android.os.Parcel;
import android.os.Parcelable;

public class GroupNameID implements Parcelable {
    private String mName;
    private Long mID;

    public GroupNameID(String name, Long ID) {
        this.mName = name;
        this.mID = ID;
    }

    protected GroupNameID(Parcel in) {
        mName = in.readString();
        if (in.readByte() == 0) {
            mID = null;
        } else {
            mID = in.readLong();
        }
    }

    public static final Creator<GroupNameID> CREATOR = new Creator<GroupNameID>() {
        @Override
        public GroupNameID createFromParcel(Parcel in) {
            return new GroupNameID(in);
        }

        @Override
        public GroupNameID[] newArray(int size) {
            return new GroupNameID[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(mName);
        if (mID == null) {
            parcel.writeByte((byte) 0);
        } else {
            parcel.writeByte((byte) 1);
            parcel.writeLong(mID);
        }
    }
}
