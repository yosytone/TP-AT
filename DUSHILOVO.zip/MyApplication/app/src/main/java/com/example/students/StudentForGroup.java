package com.example.students;

import android.os.Parcel;
import android.os.Parcelable;

public class StudentForGroup implements Parcelable {
    private Student mStudent;
    private Long mGroupID;

    public StudentForGroup(Student mStudent, Long mGroup) {
        this.mStudent = mStudent;
        this.mGroupID = mGroup;
    }

    protected StudentForGroup(Parcel in) {
        mStudent = in.readParcelable(Student.class.getClassLoader());
        if (in.readByte() == 0) {
            mGroupID = null;
        }
        else {
            mGroupID = in.readLong();
        }

    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(mStudent, flags);
        if (mGroupID == null) {
            dest.writeByte((byte) 0);
        }
        else {
            dest.writeByte((byte) 1);
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<StudentForGroup> CREATOR = new Creator<StudentForGroup>() {
        @Override
        public StudentForGroup createFromParcel(Parcel in) {
            return new StudentForGroup(in);
        }

        @Override
        public StudentForGroup[] newArray(int size) {
            return new StudentForGroup[size];
        }
    };

    public Student getStudent() {
        return mStudent;
    }

    public Long getGroupID() {
        return mGroupID;
    }
}
